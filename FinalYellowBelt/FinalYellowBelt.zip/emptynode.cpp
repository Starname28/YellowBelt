#include "emptynode.h"

bool EmptyNode::Evaluate(const Date& date, const std::string& event) const
{
    return true;
}
